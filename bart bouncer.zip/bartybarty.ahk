#Requires AutoHotkey v2.0
#SingleInstance Force

global myGui := ""
global timerActive := false

; Physics parameters
global posX := 100.0
global posY := 100.0
global vx := 12.0        ; Horizontal speed (pixels per frame)
global vy := 0.0         ; Vertical speed
global gravity := 0.6    ; Gravity acceleration
global winW := 300       ; Window width
global winH := 225       ; Window height

#b:: {
    global myGui, timerActive, posX, posY, vx, vy

    ; Toggle window off if it's already active
    if (myGui != "") {
        SetTimer(UpdatePhysics, 0)
        myGui.Destroy()
        myGui := ""
        timerActive := false
        return
    }

    ; Image file path relative to the script directory
    targetFolder := A_ScriptDir "\Downloaded_Images"
    imgPath := targetFolder "\bean.png"

    ; Check if the image exists locally
    if !FileExist(imgPath) {
        MsgBox("Image not found!`n`nPlease place your image at:`n" imgPath, "Error", "Icon!")
        return
    }

    ; Create window
    myGui := Gui("+AlwaysOnTop", "Bouncing Bean")
    myGui.MarginX := 0
    myGui.MarginY := 0
    myGui.Add("Pic", "w" winW " h" winH, imgPath)
    
    ; Initial position and display
    posX := 100.0
    posY := 100.0
    vy := 0.0
    myGui.Show("x" Integer(posX) " y" Integer(posY) " w" winW " h" winH " NoActivate")

    ; Start physics loop (~60 FPS)
    SetTimer(UpdatePhysics, 16)
    timerActive := true
}

UpdatePhysics() {
    global myGui, posX, posY, vx, vy, gravity, winW, winH

    if (myGui == "")
        return

    ; Retrieve desktop work area bounds
    MonitorGetWorkArea(1, &Left, &Top, &Right, &Bottom)

    ; Physics engine
    vy += gravity
    posX += vx
    posY += vy

    ; Wall bounce (Left / Right)
    if (posX <= Left) {
        posX := Left
        vx := Abs(vx)
    } else if (posX + winW >= Right) {
        posX := Right - winW
        vx := -Abs(vx)
    }

    ; Floor bounce
    if (posY + winH >= Bottom) {
        posY := Bottom - winH
        vy := -Abs(vy)
        if (Abs(vy) < 10)
            vy := -15.0
    }

    ; Ceiling bounce
    if (posY <= Top) {
        posY := Top
        vy := Abs(vy)
    }

    myGui.Show("x" Integer(posX) " y" Integer(posY) " NoActivate")
}

; Press Escape to close the window
Esc:: {
    global myGui
    if (myGui != "") {
        SetTimer(UpdatePhysics, 0)
        myGui.Destroy()
        myGui := ""
    }
}